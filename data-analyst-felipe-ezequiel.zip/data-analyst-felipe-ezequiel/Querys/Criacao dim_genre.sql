CREATE TABLE dim_genre (
    genre_id SERIAL PRIMARY KEY,
    genre_name TEXT UNIQUE
);

INSERT INTO dim_genre (genre_name)
SELECT DISTINCT genre_name FROM onerpm;


ALTER TABLE onerpm ADD COLUMN genre_id_new INT;

UPDATE onerpm o
SET genre_id_new = d.genre_id
FROM dim_genre d
WHERE o.genre_name = d.genre_name;
