ALTER TABLE country_mapping RENAME TO dim_country;
