CREATE TABLE dim_tempo (
    data_id SERIAL PRIMARY KEY,
    data DATE NOT NULL,
    ano INT NOT NULL,
    mes INT NOT NULL,
    nome_mes TEXT NOT NULL,
    trimestre INT NOT NULL,
    semestre INT NOT NULL,
    dia INT NOT NULL,
    dia_da_semana INT NOT NULL,
    nome_dia TEXT NOT NULL,
    ano_mes TEXT NOT NULL
);




INSERT INTO dim_tempo (data, ano, mes, nome_mes, trimestre, semestre, dia, dia_da_semana, nome_dia, ano_mes)
SELECT 
    d::DATE AS data,
    EXTRACT(YEAR FROM d) AS ano,
    EXTRACT(MONTH FROM d) AS mes,
    TO_CHAR(d, 'Month') AS nome_mes,
    EXTRACT(QUARTER FROM d) AS trimestre,
    CASE WHEN EXTRACT(QUARTER FROM d) IN (1,2) THEN 1 ELSE 2 END AS semestre,
    EXTRACT(DAY FROM d) AS dia,
    EXTRACT(ISODOW FROM d) AS dia_da_semana,
    TO_CHAR(d, 'Day') AS nome_dia,
    TO_CHAR(d, 'YYYY-MM') AS ano_mes
FROM GENERATE_SERIES('2022-01-01'::DATE, '2024-12-31'::DATE, '1 day'::INTERVAL) d;


ALTER TABLE onerpm ADD COLUMN data_id INT;

UPDATE onerpm o
SET data_id = d.data_id
FROM dim_tempo d
WHERE o.date = d.data;

